name = 'I3ToSQLite'
from .tools import *
from .CreateTemporaryDatabases import *
from .MergeTemporaryDatabases import *
__version__ = "0.1.10"
__author__ = 'Rasmus F. Ørsøe'
__credits__ = 'Niels Bohr Instutite, IceCube Collaboration'